package com.tns.placementManagementSystem.restFullAPIs.repository;

public interface UserRepository {

}
